$(window).load(function(){
    $('#boot').show(0).delay(5000).fadeOut('slow');
});